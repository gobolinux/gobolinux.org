# LaTeX2HTML 2002 (1.62)
# Associate images original text with physical files.


$key = q/{figure}texttt{{footnotesize{slash~~~~~~~~~~~~~~~~~~~~~~~}{{footnotesize{Rootdir{devfilesystem}{{footnotesize{)}{{footnotesize{{par{}{par{{{{figure};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="514" HEIGHT="269" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\begin{figure}\texttt{\footnotesize /&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}{\footnotesize Root...
...tnotesize dev file system}{\footnotesize )}{\footnotesize\par }
\par\end{figure}">|; 

1;

